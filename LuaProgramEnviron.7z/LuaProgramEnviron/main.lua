--Argumentos de linea de comando

io.write("Ingrese un texto: ")
local entrada = io.read()
print("Usted ha escrito:",entrada)

--Standard Streams: Standard Input, Output y Error

io.write("Ingrese su nombre: ")
local nombre = io.read()
print("Hola, " .. nombre)

io.write("Este es un mensaje de salida.\n")

io.stderr:write("Este es un mensaje de error.\n")

--Variables de ambiente
local ruta_path = os.getenv("PATH")
print("El valor de PATH es:", ruta_path)


--File I/O

local archivo = io.open("C:\\Users\\WinterTreat\\Desktop\\LuaProgram\\test.txt", "r")

if archivo then

    local contenido = archivo:read("*all")   
    archivo:close()  
    print(contenido)
else
    print("No se pudo abrir el archivo.")
end


local archivo = io.open("C:\\Users\\WinterTreat\\Desktop\\LuaProgram\\test.txt", "w")

if archivo then
    archivo:write("Hola, mundo!\n")
    archivo:write("Este es un ejemplo de escritura en Lua.\n")
    archivo:close()
    
    print("Archivo escrito exitosamente.")
else
    print("No se pudo abrir el archivo para escritura.")
end

--Network I/O // Recordar librerías necesarias.

local socket = require("socket")

local client = socket.tcp()
client:connect("www.example.com", 80)

client:send("GET / HTTP/1.1\r\nHost: www.example.com\r\n\r\n")

local respuesta, estado = client:receive("*a")
if estado == "closed" then
    print("Conexión cerrada por el servidor.")
else
    print(respuesta)
end

client:close()